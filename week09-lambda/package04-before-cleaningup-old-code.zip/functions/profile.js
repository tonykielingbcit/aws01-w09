import * as dbMethods from "../db/profile-db.js";


export const getProfileById = async (userId) => {
console.log("XXXXXXXXXXXXXXXXXXXXXXX userId:::::::::::: ", userId)
    const user = await dbMethods.getProfileById(userId);
console.log("user:::::::::::: ", user)
    return user
};

