import * as dbMethods from "../db/profile-db.js";


export const getProfileById = async userId => {
console.log("XXXXXXXXXXXXXXXXXXXXXXX userId:::::::::::: ", userId)
    const user = await dbMethods.getProfileById(userId);
console.log("user:::::::::::: ", user)
    return user
};


export const updateProfile = async (userId, city, bio) => {
    console.log("XXXXXXXXXXXXXXXXXXXXXXX userId:::::::::::: ", userId)
        try {
            const user = await dbMethods.updateProfile(userId, city, bio);
        console.log("user::::::::::::after:::::::::::: ", user)
            return ({ message: user });
        } catch(err) {
            console.log("###ERROR on updateProfile: ", err.messsage || err);
            return ({ error: "Error on updateing Profile"});
        }
};









export const getTodoItemById = async todoId => {
    console.log("XXXXXXXXXXXXXXXXXXXXXXX todoId:::::::::::: ", todoId)
        const todoItem = await dbMethods.getTodoItemById(todoId);
    console.log("user:::::::::::: ", todoItem)
        return todoItem
};