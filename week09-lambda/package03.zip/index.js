import * as dbMethods from "./db/db.js";
import * as profileFunctions from "./functions/profile.js";

export const handler = async event => {
    console.log("EVENT::::::::::::::::::::::::::::::::::::", event)
    const userId = event.requestContext.authorizer.jwt.claims.sub;
    
    try {
        const method = event.requestContext.http.method;
        switch (method) {
            case "GET":
                // receive: nothing OR getId param
                // return: all items in DB or the particular item caught from getId
                
                // const profiles = await dbMethods.getAllProfiles();
                // return {
                //   statusCode: 200,
                // //   body: JSON.stringify(profiles),
                //   body: JSON.stringify(event.pathParameters.id)
                // }

                const rawPath = event.rawPath;
                if (rawPath.includes("userId")) {
                    // it forwards to profile functions
                    return {
                        statusCode: 200,
                        body: {
                            message: await profileFunctions.getUserById(userId)
                        }
                    };
                }

                break;
            
        // };
        // return response;
                /*case "POST": {
                    // receive: body.newItem
                    // return: new list of items in DB
                    const body = JSON.parse(event.body);
                    const {error} = body;
                    if (error) throw (`Testing Error was Successful and received: '${error}'`);
                    
                }*/
                case "PUT": {
                    // receive: body.id & body.updateItem
                    // return: only the new object inserted in DB
                    /*const body = JSON.parse(event.body);
                    const { id, updateItem } = body;
                    const changeItem = await db.updateItem(id, updateItem);
                    msg = changeItem;*/
                    
                    const userId = event.requestContext.authorizer.jwt.claims.sub;
        const profiles = await dbMethods.getProfileById(userId);
    
        const response = {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Hello from Lambda PUTTTT!',
                receivedData: event.body,
                profiles,
                paramReceived: event.pathParameters.profileIdToUpdate
            }),
        };
        return response;
                }
    /*            case "DELETE": {
                    // receive: body.itemIdToBeDelete
                    // return: new list of items in DB
                    const body = JSON.parse(event.body);
                    const { itemIdToBeDelete } = body;
                    await db.removeItem(itemIdToBeDelete);
                    const newItemsList = await db.getAllItems();
                    msg = newItemsList;
                    break;
                }*/
                default:
                // Gateway API suppose to handle this before this point0
                    // msg = "something wrong :(";
                    // break
            }
        
            // this code is suppose to be not reachable
            const response = {
                statusCode: 200,
                body: JSON.stringify({message: "something happened..;"})
            };
            return response;
        } catch(err) {
            console.log("###ERROR - general error: ", err.message || err);
            return ({
                statusCode: 500,
                body: JSON.stringify({error: err.message || err})
            });
        }
    };
    