import * as dbMethods from "./db/db.js";


export const getUserById = async (userId) => {
console.log("XXXXXXXXXXXXXXXXXXXXXXX userId:::::::::::: ", userId)
    const user = await dbMethods.getUserById(userId);
console.log("user:::::::::::: ", user)
    return user
};

